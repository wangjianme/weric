var curFrame = false;
var zIndex = 1;
var preFrame = false;
