package spider;

public class ContentChecker {
	
	public String checkLine(String[] values,int[] requestIndex){
		return "";
	}
}
